//
//  ProviderViewController.swift
//  Hospital Bed Management
//
//  Created by Ahsan Habib on 11/13/22.
//

import UIKit
import FirebaseAuth
import Firebase
import FirebaseFirestore
	

class ProviderViewController: UIViewController {
    @IBOutlet weak var hos_name: UILabel!
    @IBOutlet weak var icu_label: UILabel!
    @IBOutlet weak var gbed_label: UILabel!
    @IBOutlet weak var icu_edit: UITextField!
    @IBOutlet weak var API_label: UILabel!
    @IBOutlet weak var gbed_edit: UITextField!
    let fbAuth = Auth.auth().currentUser!.uid
    struct Response: Codable {
        let name: String
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = "https://mocki.io/v1/24343bb6-5c2f-4a96-a26d-77563d6f676c"
        let task = URLSession.shared.dataTask(with: URL( string: url)!, completionHandler: { data, response, error in
            guard let data = data, error == nil else{
                print("something went wrong")
                return
            }
            
            var result: Response?
            do {
                result = try JSONDecoder().decode(Response.self, from: data)
            }
            catch{
                print("failed to convert")
            }
            
            guard let json =  result else {
                return
            }
            
            
            //for showing output in label named jsonview
            self.API_label.text = json.name
            
        })
        task.resume()
        getData()
        // Do any additional setup after loading the view.
    }
    
    struct Hospital{
        let name: String
        let icuBed: String
        let generalBed: String
        let mobile_number: String
        let address: String
    }
    
    @IBAction func save(_ sender: Any) {
        updateData()
    }
    var data = [Hospital]()

    @IBAction func signOut(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        
        do {
          try firebaseAuth.signOut()
            
            let storyboard = UIStoryboard(name:"Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "login")
            vc.modalPresentationStyle = .overFullScreen
            self.present(vc, animated: true)
            
        } catch let signOutError as NSError {
          print("Error signing out: %@", signOutError)
        }
    }
    func updateData(){
        let db  = Database.database().reference().child("provider").child(fbAuth)
        var x = Int(self.icu_edit.text!)
        var y = Int(self.icu_label.text!)
        x = y! - x!
        db.updateChildValues(["bookedIcuBed":String(x!)])
        var x1 = Int(self.gbed_edit.text!)
        var y1 = Int(self.gbed_label.text!)
        x1 = y1! - x1!
        db.updateChildValues(["bookedGeneralBed":String(x1!)])
    }
    
    func getData()
    {
        Database.database().reference().child("provider").child(fbAuth).observeSingleEvent(of: .value, with: { snapshot in
          // Get user value
            let value = snapshot.value as? NSDictionary
            self.hos_name.text = value?["name"] as? String
            self.icu_label.text = value?["icuBed"] as? String
            self.gbed_label.text = value?["generalBed"] as? String
            var icu_av = Int((value?["bookedIcuBed"] as? String)!)
            var x = Int((value?["icuBed"] as? String)!)
            icu_av = x! - icu_av!
            self.icu_edit.text = String(icu_av!)
            var gbed_av = Int((value?["bookedGeneralBed"] as? String)!)
            var y = Int((value?["generalBed"] as? String)!)
            gbed_av = y! - gbed_av!
            self.gbed_edit.text = String(gbed_av!)
        }) { error in
          print(error.localizedDescription)
        }    }
    
    

}
