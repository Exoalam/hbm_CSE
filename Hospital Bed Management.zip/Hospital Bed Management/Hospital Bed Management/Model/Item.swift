//
//  Item.swift
//  Hospital Bed Management
//
//  Created by Ahsan Habib on 11/13/22.
//

import Foundation

struct Item{
    var name: String
    var availableICUBed: String
    var availableGeneralBed: String
}
