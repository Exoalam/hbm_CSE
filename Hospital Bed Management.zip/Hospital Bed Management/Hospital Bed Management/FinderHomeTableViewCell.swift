//
//  FinderHomeTableViewCell.swift
//  Hospital Bed Management
//
//  Created by Ahsan Habib on 11/13/22.
//

import UIKit

class FinderHomeTableViewCell: UITableViewCell {

    @IBOutlet weak var hospitalName: UILabel!
    @IBOutlet weak var icuBedNo: UILabel!
    @IBOutlet weak var generalBedNo: UILabel!
    

}
